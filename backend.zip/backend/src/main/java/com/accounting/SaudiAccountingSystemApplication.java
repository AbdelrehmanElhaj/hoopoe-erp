package com.accounting;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SaudiAccountingSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(SaudiAccountingSystemApplication.class, args);
	}

}
